if (localStorage.getItem("esAdmin") == "0") {
    top.location.href = "login";
};